// --- Configurações Globais ---
const API_BASE_URL = 'http://localhost:3000/pratos';
const containersPorCategoria = {
    destaques: document.getElementById('pratos-container-destaques'),
    executivos: document.getElementById('pratos-container-executivos'),
    massas: document.getElementById('pratos-container-massas'),
    sobremesas: document.getElementById('pratos-container-sobremesas'),
    bebidas: document.getElementById('pratos-container-bebidas'),
};
const searchForm = document.querySelector('header nav form');
const searchInput = document.querySelector('header nav input[type="text"]');
const searchResultsContainer = document.getElementById('searchResultsContainer');
const userNameElement = document.getElementById('userName');
const userIcon = document.querySelector('a[href="./src/pages/login/index.html"]');
const cart = [];
const cartItemCountSpan = document.getElementById('cartItemCount');
const cartTotalSpan = document.getElementById('cartTotal');
const cartItemsContainer = document.getElementById('cartItemsContainer');
const cartModal = document.getElementById('cartModal');
const closeButton = document.querySelector('.close-button');
const checkoutButton = document.getElementById('checkoutButton');
const emptyCartMessage = document.getElementById('emptyCartMessage');

// --- Funções Auxiliares ---
function gerarPrecoAleatorio(min = 30, max = 120) {
    return parseFloat((Math.random() * (max - min) + min).toFixed(2));
}

function criarCardPrato(prato, categoria) {
    const card = document.createElement('div');
    card.className = 'card';
    card.innerHTML = `
        <img src="${prato.image}" alt="${prato.name}">
        <h2>${prato.name}</h2>
        <p>${prato.description || 'Descrição não disponível.'}</p>
        <p class="dish-price">R$ ${prato.price.toFixed(2).replace('.', ',')}</p>
        <div class="card-buttons">
            <button class="btn btn-details">Detalhes</button>
            <button class="btn btn-add-to-cart">+</button>
        </div>
    `;
    card.querySelector('.btn-details').addEventListener('click', () => {
        alert(`Detalhes do prato: ${prato.name}\nPreço: R$ ${prato.price.toFixed(2).replace('.', ',')}`);
    });
    card.querySelector('.btn-add-to-cart').addEventListener('click', () => {
        addToCart(prato);
    });
    return card;
}

async function fetchAPI(endpoint) {
    try {
        const response = await fetch(endpoint);
        if (!response.ok) throw new Error(`Erro: ${response.statusText}`);
        return await response.json();
    } catch (error) {
        console.error(`Erro ao buscar dados da API: ${error.message}`);
        return null;
    }
}

// --- Funções Principais ---
async function carregarCategorias() {
    try {
        const categorias = await fetchAPI(`${API_BASE_URL}/prato/categoria`);
        if (categorias && categorias.categories) {
            const classificationHighlight = document.querySelector('.classification-highlight');
            categorias.categories.forEach(categoria => {
                const categoryName = categoria.strCategory.toLowerCase();
                containersPorCategoria[categoryName] = document.createElement('div');
                containersPorCategoria[categoryName].id = `${categoryName}-content`;
                containersPorCategoria[categoryName].className = 'category-content';
                document.querySelector('main').appendChild(containersPorCategoria[categoryName]);

                const categoryLink = document.createElement('a');
                categoryLink.href = `#${categoryName}-content`;
                categoryLink.className = 'category-block';
                categoryLink.textContent = categoria.strCategory.toUpperCase();
                classificationHighlight.appendChild(categoryLink);
            });
        } else {
            console.warn('Nenhuma categoria encontrada na API.');
        }
    } catch (error) {
        console.error('Erro ao carregar categorias:', error);
    }
}

async function carregarPratosPorCategoria(categoria) {
    const pratos = await fetchAPI(`${API_BASE_URL}/categoria/${categoria}`);
    if (pratos && pratos.length > 0) {
        const container = containersPorCategoria[categoria];
        container.innerHTML = '';
        pratos.forEach(prato => {
            const card = criarCardPrato(prato, categoria);
            container.appendChild(card);
        });
    } else {
        console.warn(`Nenhum prato encontrado para a categoria: ${categoria}`);
    }
}

async function buscarPratosPorNome(nome) {
    const pratos = await fetchAPI(`${API_BASE_URL}/nome/${nome}`);
    searchResultsContainer.innerHTML = '';
    searchResultsContainer.style.display = 'block';

    if (pratos && pratos.length > 0) {
        const heading = document.createElement('h2');
        heading.textContent = `Resultados para "${nome}"`;
        searchResultsContainer.appendChild(heading);

        const grid = document.createElement('div');
        grid.className = 'pratos-categoria-container';
        pratos.forEach(prato => {
            const card = criarCardPrato(prato, 'destaques');
            grid.appendChild(card);
        });
        searchResultsContainer.appendChild(grid);
    } else {
        searchResultsContainer.innerHTML = `<p>Nenhum prato encontrado para "${nome}".</p>`;
    }
}

function updateCartDisplay() {
    cartItemsContainer.innerHTML = '';
    if (cart.length === 0) {
        emptyCartMessage.style.display = 'block';
        checkoutButton.disabled = true;
    } else {
        emptyCartMessage.style.display = 'none';
        checkoutButton.disabled = false;
        let total = 0;
        cart.forEach(item => {
            const itemElement = document.createElement('div');
            itemElement.className = 'cart-item';
            itemElement.innerHTML = `
                <div class="cart-item-info">
                    <img src="${item.image}" alt="${item.name}">
                    <div class="cart-item-details">
                        <h4>${item.name}</h4>
                        <p>R$ ${item.price.toFixed(2).replace('.', ',')}</p>
                    </div>
                </div>
                <div class="cart-item-controls">
                    <button class="quantity-btn decrease-quantity" data-id="${item.id}">-</button>
                    <span>${item.quantity}</span>
                    <button class="quantity-btn increase-quantity" data-id="${item.id}">+</button>
                    <button class="remove-item-btn" data-id="${item.id}">Remover</button>
                </div>
            `;
            cartItemsContainer.appendChild(itemElement);
            total += item.price * item.quantity;
        });
        cartTotalSpan.textContent = `R$ ${total.toFixed(2).replace('.', ',')}`;
    }
    cartItemCountSpan.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);
}

function addToCart(item) {
    const existingItem = cart.find(cartItem => cartItem.id === item.id);
    if (existingItem) {
        existingItem.quantity++;
    } else {
        cart.push({ ...item, quantity: 1 });
    }
    updateCartDisplay();
    alert(`"${item.name}" adicionado à sacola!`);
}

// --- Inicialização ---
document.addEventListener('DOMContentLoaded', async () => {
    // Carregar categorias
    await carregarCategorias();

    // Carregar pratos por categoria
    Object.keys(containersPorCategoria).forEach(categoria => carregarPratosPorCategoria(categoria));

    // Configurar busca
    searchForm.addEventListener('submit', async event => {
        event.preventDefault();
        const searchTerm = searchInput.value.trim();
        if (searchTerm) {
            await buscarPratosPorNome(searchTerm);
        } else {
            alert('Por favor, digite um termo para buscar.');
        }
    });

    // Verificar usuário logado
    const userId = localStorage.getItem('userId');
    if (userId) {
        const user = await fetchAPI(`http://localhost/usuarios/${userId}`);
        if (user && user.name) {
            userNameElement.textContent = `Olá, ${user.name}`;
        } else {
            userNameElement.textContent = '';
        }
    }

    // Configurar clique no ícone de usuário
    userIcon.addEventListener('click', event => {
        event.preventDefault();
        if (userId) {
            window.location.href = './src/pages/account/index.html';
        } else {
            window.location.href = './src/pages/login/index.html';
        }
    });
});